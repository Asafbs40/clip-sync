"""CLIPSYNC face-blur core: open-source YuNet detection + ffmpeg re-encode.

Two passes so we can blur *before* a face is first detected and *after* it is
last detected (temporal dilation). Privacy bias: low detection threshold, padded
boxes, and any failure raises (we never return an unblurred file as blurred).
"""
from __future__ import annotations

import json
import os
import subprocess
from dataclasses import dataclass, asdict

import cv2
import numpy as np

MODEL_PATH = os.environ.get("YUNET_MODEL", os.path.join(os.path.dirname(__file__), "yunet.onnx"))


@dataclass
class BlurStats:
    frames: int
    fps: float
    width: int
    height: int
    frames_with_faces: int
    faces_detected_raw: int
    min_score_used: float
    dilation_frames: int
    pad: float

    def to_json(self) -> dict:
        return asdict(self)


def _probe_audio(path: str) -> bool:
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "a", "-show_entries", "stream=index", "-of", "json", path],
        capture_output=True, text=True, check=True,
    ).stdout
    return bool(json.loads(out or "{}").get("streams"))


def detect_pass(path: str, score: float = 0.5, detect_width: int = 960, stride: int = 1):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        raise RuntimeError("cannot open video")
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    boxes: list[list[tuple[int, int, int, int]]] = []
    det = None
    last: list[tuple[int, int, int, int]] = []
    w = h = 0
    idx = 0
    raw = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if det is None:
            h, w = frame.shape[:2]
            scale = min(1.0, detect_width / max(w, h))
            dw, dh = max(32, int(w * scale)), max(32, int(h * scale))
            det = cv2.FaceDetectorYN.create(MODEL_PATH, "", (dw, dh), score, 0.3, 5000)
        else:
            scale = min(1.0, detect_width / max(w, h))
            dw, dh = max(32, int(w * scale)), max(32, int(h * scale))
        if idx % stride == 0:
            small = cv2.resize(frame, (dw, dh)) if scale < 1.0 else frame
            _, faces = det.detect(small)
            cur = []
            if faces is not None:
                for f in faces:
                    x, y, bw, bh = f[:4] / scale
                    cur.append((int(x), int(y), int(bw), int(bh)))
            raw += len(cur)
            last = cur
        boxes.append(list(last))
        idx += 1
    cap.release()
    if idx == 0:
        raise RuntimeError("no frames decoded")
    return boxes, fps, w, h, raw


def dilate_boxes(boxes, k: int):
    """Union of boxes from frames t-k..t+k so faces are covered slightly early/late."""
    n = len(boxes)
    out = []
    for t in range(n):
        acc = []
        for j in range(max(0, t - k), min(n, t + k + 1)):
            acc.extend(boxes[j])
        out.append(acc)
    return out


def _blur_region(frame: np.ndarray, box, pad: float) -> None:
    h, w = frame.shape[:2]
    x, y, bw, bh = box
    cx, cy = x + bw / 2, y + bh / 2
    rw, rh = bw * (1 + pad) / 2, bh * (1 + pad * 1.4) / 2  # a bit more headroom (hair/forehead)
    x0, x1 = int(max(0, cx - rw)), int(min(w, cx + rw))
    y0, y1 = int(max(0, cy - rh * 1.05)), int(min(h, cy + rh))
    if x1 - x0 < 4 or y1 - y0 < 4:
        return
    roi = frame[y0:y1, x0:x1]
    k = max(15, (max(roi.shape[:2]) // 3) | 1)
    blurred = cv2.GaussianBlur(roi, (k, k), 0)
    # pixelate on top so the blur cannot be reversed
    ph, pw = max(2, roi.shape[0] // 14), max(2, roi.shape[1] // 14)
    small = cv2.resize(blurred, (pw, ph), interpolation=cv2.INTER_LINEAR)
    pix = cv2.resize(small, (roi.shape[1], roi.shape[0]), interpolation=cv2.INTER_NEAREST)
    mask = np.zeros(roi.shape[:2], np.uint8)
    cv2.ellipse(mask, (roi.shape[1] // 2, roi.shape[0] // 2), (roi.shape[1] // 2, roi.shape[0] // 2), 0, 0, 360, 255, -1)
    mask = cv2.GaussianBlur(mask, (0, 0), max(1.0, roi.shape[1] / 40))
    m = (mask.astype(np.float32) / 255.0)[..., None]
    frame[y0:y1, x0:x1] = (pix * m + roi * (1 - m)).astype(np.uint8)


def blur_video(
    src: str,
    dst: str,
    score: float = 0.4,
    pad: float = 0.5,
    dilation_seconds: float = 0.4,
    detect_width: int = 960,
    crf: int = 20,
    stride: int = 2,
) -> BlurStats:
    boxes, fps, w, h, raw = detect_pass(src, score=score, detect_width=detect_width, stride=stride)
    k = max(1, int(round(dilation_seconds * fps)))
    boxes = dilate_boxes(boxes, k)
    has_audio = _probe_audio(src)

    cmd = [
        "ffmpeg", "-y", "-v", "error",
        "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{w}x{h}", "-r", f"{fps}", "-i", "-",
    ]
    if has_audio:
        cmd += ["-i", src, "-map", "0:v:0", "-map", "1:a:0", "-c:a", "copy"]
    cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", str(crf), "-pix_fmt", "yuv420p", "-movflags", "+faststart", "-shortest", dst]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)

    cap = cv2.VideoCapture(src)
    n = 0
    with_faces = 0
    try:
        for t in range(len(boxes)):
            ok, frame = cap.read()
            if not ok:
                break
            if boxes[t]:
                with_faces += 1
                for b in boxes[t]:
                    _blur_region(frame, b, pad)
            proc.stdin.write(frame.tobytes())
            n += 1
    finally:
        cap.release()
        proc.stdin.close()
        rc = proc.wait()
    if rc != 0 or n == 0:
        raise RuntimeError("ffmpeg encode failed")
    return BlurStats(n, fps, w, h, with_faces, raw, score, k, pad)
