import os, json, time, hmac, hashlib, threading, http.server, socketserver
os.environ.update(WORKER_SHARED_SECRET="s3cret", ALLOWED_HOST_SUFFIXES="localhost")
from fastapi.testclient import TestClient
import server
c=TestClient(server.app)
body=json.dumps({"job_id":"j1","source_url":"http://localhost/x","upload_url":"https://localhost/u","callback_url":"https://localhost/cb"}).encode()
ts=str(int(time.time()))
# bad signature
assert c.post("/v1/blur",content=body,headers={"X-Clipsync-Timestamp":ts,"X-Clipsync-Signature":"00"}).status_code==401
# stale timestamp
old=str(int(time.time())-1000); assert c.post("/v1/blur",content=body,headers={"X-Clipsync-Timestamp":old,"X-Clipsync-Signature":server.sign(body,old)}).status_code==401
# http (non-https) source rejected even when signed
assert c.post("/v1/blur",content=body,headers={"X-Clipsync-Timestamp":ts,"X-Clipsync-Signature":server.sign(body,ts)}).status_code==400
# host not in allowlist
b2=json.dumps({"job_id":"j","source_url":"https://evil.example/x","upload_url":"https://localhost/u","callback_url":"https://localhost/cb"}).encode()
assert c.post("/v1/blur",content=b2,headers={"X-Clipsync-Timestamp":ts,"X-Clipsync-Signature":server.sign(b2,ts)}).status_code==400
# valid job accepted
b3=json.dumps({"job_id":"j","source_url":"https://localhost/x","upload_url":"https://localhost/u","callback_url":"https://localhost/cb"}).encode()
r=c.post("/v1/blur",content=b3,headers={"X-Clipsync-Timestamp":ts,"X-Clipsync-Signature":server.sign(b3,ts)}); assert r.status_code==202,r.text
print("server auth/SSRF tests passed")
