import os, json, threading, http.server, socketserver
os.environ.update(WORKER_SHARED_SECRET="s3cret", ALLOWED_HOST_SUFFIXES="localhost")
import server
got={}
class H(http.server.BaseHTTPRequestHandler):
    def log_message(s,*a): pass
    def do_GET(s):
        d=open("test_in.mp4","rb").read(); s.send_response(200); s.send_header("content-length",str(len(d))); s.end_headers(); s.wfile.write(d)
    def do_PUT(s):
        n=int(s.headers["content-length"]); got["up"]=s.rfile.read(n); s.send_response(200); s.end_headers()
    def do_POST(s):
        n=int(s.headers["content-length"]); b=s.rfile.read(n); got["cb"]=(json.loads(b), s.headers["X-Clipsync-Signature"], s.headers["X-Clipsync-Timestamp"], b); s.send_response(200); s.end_headers()
srv=socketserver.TCPServer(("127.0.0.1",0),H); port=srv.server_address[1]; threading.Thread(target=srv.serve_forever,daemon=True).start()
u=f"http://127.0.0.1:{port}"
server.run_job({"job_id":"j1","source_url":u+"/src","upload_url":u+"/up","callback_url":u+"/cb"})
cb,sig,ts,raw=got["cb"]; print(cb["status"], cb.get("stats",{}).get("frames_with_faces"), len(got.get("up",b"")))
assert cb["status"]=="done" and sig==server.sign(raw,ts) and len(got["up"])>10000
# failure path: bad source -> failed, not done
got.clear()
server.run_job({"job_id":"j2","source_url":u+"/src","upload_url":"http://127.0.0.1:1/nope","callback_url":u+"/cb"})
assert got["cb"][0]["status"]=="failed"; print("failure path ok:", got["cb"][0]["error"][:60])
