# CLIPSYNC face-blur worker

Open-source (OpenCV YuNet face detector + ffmpeg). No per-minute vendor fee. Runs as one small container.

## What it does
1. Hub server sends a signed job: source clip URL (signed GET), upload URL (signed PUT), callback URL.
2. Worker downloads the clip, detects faces on every 2nd frame (low threshold, padded boxes), extends each detection
   0.4 s before/after, blurs + pixelates the region, re-encodes H.264 and copies the original audio.
3. Worker uploads the blurred copy and sends a signed callback: `done` (with stats) or `failed`.
   It never reports `done` unless the file was produced and uploaded.

## Measured on the build machine (2 vCPU, 720p30 test clip)
- ~7 frames/second end to end (about 4-5 minutes of compute per minute of footage). Detection is not the bottleneck.
- Test clip: face fully obscured in the output (sharpness in the face region fell from 871 to 149), audio preserved.

## Known limits (be honest in product copy)
- Detects mostly front-facing and three-quarter faces. Profile, back-of-head, very small/distant, heavily masked or
  very dark faces can be missed. Product copy must say "automatically blurs detected faces", never "guarantees".
- Tested only on one synthetic clip made from a stock portrait. It must be validated on real glasses footage
  (night, motion blur, crowds, children, reflections) before launch.

## Deploy (any container host: Fly.io, Google Cloud Run, Railway, Render)
    docker build -t clipsync-blur .
    docker run -p 8080:8080 \
      -e WORKER_SHARED_SECRET=<long random> \
      -e ALLOWED_HOST_SUFFIXES=supabase.co,lovable.app,clip-sync.com \
      -e MAX_CONCURRENT_JOBS=1 clipsync-blur
Set the allowed host suffixes to the Hub's storage and callback hosts only (fail-closed if empty).
Use 2+ vCPU, 2-4 GB RAM. Scale by raising instances, not MAX_CONCURRENT_JOBS.

## Hub integration contract
POST {WORKER_URL}/v1/blur with JSON {job_id, source_url, upload_url, callback_url}
Headers: X-Clipsync-Timestamp (unix s), X-Clipsync-Signature = hex HMAC-SHA256(secret, "<ts>.<raw body>").
Callback to the Hub uses the same signing; the Hub must verify it and reject timestamps older than 5 minutes.

## Tests
    python3 make_test.py && ffmpeg -i test_in_silent.mp4 -f lavfi -i sine=frequency=440:duration=4 -c:v copy -c:a aac -shortest test_in.mp4
    python3 test_server.py   # signature, stale timestamp, https-only, host allowlist
    python3 test_e2e.py      # full job: download, blur, upload, signed callback, failure path
