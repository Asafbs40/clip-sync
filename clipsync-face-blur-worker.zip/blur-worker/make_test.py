import cv2, numpy as np
from skimage import data
face=cv2.cvtColor(data.astronaut(),cv2.COLOR_RGB2BGR)
W,H,fps,secs=1280,720,30,4
out=cv2.VideoWriter("test_in_silent.mp4",cv2.VideoWriter_fourcc(*"mp4v"),fps,(W,H))
bg=np.full((H,W,3),(60,40,30),np.uint8)
for t in range(fps*secs):
    f=bg.copy()
    x=int(100+ (W-700)*t/(fps*secs))
    f[100:612,x:x+512]=face
    if t<fps*1 : pass
    out.write(f)
out.release()
