"""CLIPSYNC face-blur worker: signed HTTP API around blur.py.

POST /v1/blur   (HMAC-signed)  -> 202 {job_id}
  body: {job_id, source_url, upload_url, callback_url}
  - source_url: signed HTTPS GET URL of the merchant's own clip (server-minted by the Hub)
  - upload_url: signed HTTPS PUT URL for the blurred copy
  - callback_url: HTTPS URL on the Hub; receives a signed JSON result
GET /healthz
Auth: header X-Clipsync-Signature = hex(HMAC_SHA256(WORKER_SHARED_SECRET, "<timestamp>.<raw body>")),
      header X-Clipsync-Timestamp = unix seconds (rejected if older than 300 s).
The same scheme signs the callback to the Hub.
Never reports status "done" unless the blurred file was produced and uploaded.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import tempfile
import threading
import time
from urllib.parse import urlparse

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse

import blur

SECRET = os.environ.get("WORKER_SHARED_SECRET", "")
ALLOWED_HOSTS = {h.strip().lower() for h in os.environ.get("ALLOWED_HOST_SUFFIXES", "").split(",") if h.strip()}
MAX_BYTES = int(os.environ.get("MAX_VIDEO_BYTES", str(2 * 1024 ** 3)))
MAX_SECONDS = int(os.environ.get("MAX_VIDEO_SECONDS", "900"))
MAX_CONCURRENT = int(os.environ.get("MAX_CONCURRENT_JOBS", "1"))
_slots = threading.Semaphore(MAX_CONCURRENT)

app = FastAPI(title="clipsync-face-blur")


def sign(body: bytes, ts: str) -> str:
    return hmac.new(SECRET.encode(), ts.encode() + b"." + body, hashlib.sha256).hexdigest()


def host_ok(url: str) -> bool:
    u = urlparse(url)
    if u.scheme != "https" or not u.hostname:
        return False
    if not ALLOWED_HOSTS:
        return False  # fail closed: must configure allowed host suffixes
    h = u.hostname.lower()
    return any(h == s or h.endswith("." + s) for s in ALLOWED_HOSTS)


def callback(url: str, payload: dict) -> None:
    body = json.dumps(payload).encode()
    ts = str(int(time.time()))
    try:
        httpx.post(url, content=body, headers={
            "content-type": "application/json", "X-Clipsync-Timestamp": ts, "X-Clipsync-Signature": sign(body, ts)}, timeout=30)
    except Exception:
        pass  # Hub also polls; never crash the worker


def run_job(job: dict) -> None:
    jid = job["job_id"]
    with _slots:
        try:
            with tempfile.TemporaryDirectory() as td:
                src, dst = os.path.join(td, "in.mp4"), os.path.join(td, "out.mp4")
                size = 0
                with httpx.stream("GET", job["source_url"], timeout=120, follow_redirects=False) as r:
                    r.raise_for_status()
                    with open(src, "wb") as f:
                        for chunk in r.iter_bytes(1 << 20):
                            size += len(chunk)
                            if size > MAX_BYTES:
                                raise RuntimeError("video too large")
                            f.write(chunk)
                import cv2
                cap = cv2.VideoCapture(src)
                n, fps = cap.get(cv2.CAP_PROP_FRAME_COUNT), cap.get(cv2.CAP_PROP_FPS) or 30
                cap.release()
                if n / fps > MAX_SECONDS:
                    raise RuntimeError("video too long")
                stats = blur.blur_video(src, dst)
                with open(dst, "rb") as f:
                    r = httpx.put(job["upload_url"], content=f.read(), headers={"content-type": "video/mp4"}, timeout=600)
                    r.raise_for_status()
                callback(job["callback_url"], {"job_id": jid, "status": "done", "stats": stats.to_json(),
                                               "output_bytes": os.path.getsize(dst)})
        except Exception as e:  # never claim success
            callback(job["callback_url"], {"job_id": jid, "status": "failed", "error": str(e)[:300]})


@app.get("/healthz")
def healthz():
    return {"ok": True, "secret_configured": bool(SECRET), "hosts_configured": bool(ALLOWED_HOSTS)}


@app.post("/v1/blur")
async def blur_endpoint(request: Request):
    if not SECRET:
        raise HTTPException(503, "worker not configured")
    raw = await request.body()
    ts = request.headers.get("X-Clipsync-Timestamp", "")
    sig = request.headers.get("X-Clipsync-Signature", "")
    if not ts.isdigit() or abs(time.time() - int(ts)) > 300 or not hmac.compare_digest(sig, sign(raw, ts)):
        raise HTTPException(401, "bad signature")
    try:
        job = json.loads(raw)
        for k in ("job_id", "source_url", "upload_url", "callback_url"):
            assert isinstance(job[k], str)
    except Exception:
        raise HTTPException(400, "bad body")
    for k in ("source_url", "upload_url", "callback_url"):
        if not host_ok(job[k]):
            raise HTTPException(400, f"{k} host not allowed")
    threading.Thread(target=run_job, args=(job,), daemon=True).start()
    return JSONResponse({"job_id": job["job_id"], "status": "accepted"}, status_code=202)
